/// Safe numeric parsing + rounding helpers used by forms and billing.

/// Parses a money value. Returns null for empty, invalid, NaN, infinite
/// or negative input. Accepts thousands separators ("1,250.50").
double? parseMoney(String? input) {
  if (input == null) return null;
  final t = input.trim().replaceAll(',', '');
  if (t.isEmpty) return null;
  final v = double.tryParse(t);
  if (v == null || !v.isFinite || v < 0) return null;
  return v;
}

/// Parses a whole, non-negative quantity. Returns null if invalid.
int? parseQuantity(String? input) {
  if (input == null) return null;
  final v = int.tryParse(input.trim());
  if (v == null || v < 0) return null;
  return v;
}

/// Rounds to 2 decimals (avoids 0.1 + 0.2 style drift in totals).
double round2(double v) => (v * 100).round() / 100;
